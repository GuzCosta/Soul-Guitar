# GuitarHeroUnity
Open Source - Guitar Hero fan game made in Unity.

After seeing the .chart files in Clone Hero, i wanted to see if i could read them in Unity. So I threw this together.

Now playable with guitar hero controller. Note hit registration can be buggy still.

DOES NOT INCLUDE SONGS.
You can place songs in the "Place Songs Here" folder, this is found in the root folder.
It plays songs that include .chart files, I've tested it with Guitar Hero 2 and Guitar Hero 3 songs.

Here is a spreadsheet with Clone Hero songs. If songs have .chart files they should work in this project:
https://docs.google.com/spreadsheets/d/13B823ukxdVMocowo1s5XnT3tzciOfruhUVePENKc01o/edit#gid=0

Guitar Hero assets have been "poorly" redrawn.
![alt text](https://i.postimg.cc/0QP8vY1t/gh-Screenshot.jpg)

Youtube video:

[![alt text](https://img.youtube.com/vi/R4eqFEGM84s/0.jpg)](https://www.youtube.com/watch?v=R4eqFEGM84s)

