﻿using System.Runtime.InteropServices;

public static class GcControl
{
	//// Unity engine function to disable the GC
	//[DllImport("__Internal")]
	//public static extern void GC_disable();

	//// Unity engine function to enable the GC
	//[DllImport("__Internal")]
	//public static extern void GC_enable();
}