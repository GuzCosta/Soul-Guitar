﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarInstance : MonoBehaviour
{
	public uint timestamp;
	public Transform myTransform;
}
